import csv
from datetime import datetime, timedelta
import sim_parameters
import numpy as np
import helper
from pathlib import Path
import os

def generate_sample_data(data, sample_ratio, age_groups):
    """
    Function to Generate sample data based on given sample ratio for respective age groups
    """
    sample_data = []
    unique_id = 0
    
    for entry in data:
        entry_population = int(float(entry['population']) / sample_ratio)
        for age_group in age_groups:
            age_group_population = int(entry_population * float(entry[age_group]) / 100)
            sample_data.extend(
                {'unique_id': unique_id + count,
                 'country': entry['country'],
                 'age_group_name': age_group}
                for count in range(age_group_population)
            )
            unique_id += age_group_population
    return sample_data, unique_id

def each_person(dataList, probabilities, holdingTime, possibleStates):
    """
    Function to predict the states for each person id
    """
    keysMap = {j: i for i, j in enumerate(probabilities.keys())}
    result = []
    counter = 0
    for index, data in enumerate(dataList):
        temp = data.copy()
        if index == 0:  # state, staying_days, prev_state
            temp['state'] = 'H'
            temp['staying_days'] = 0
            temp['prev_state'] = 'H'
        else:
            if counter >= holdingTime[result[-1]['state']]:
                counter = 0
                state = result[-1]['state']
                temp_states = possibleStates[keysMap[state]]
                temp_probs = [probabilities[state].get(j, 0) for j in keysMap]
                temp['state'] = np.random.choice(temp_states, p=temp_probs)[1]
            else:
                counter += 1
                temp['state'] = result[-1]['state']
        temp['staying_days'] = counter
        temp['prev_state'] = result[-1]['state'] if index > 0 else 'H'
        result.append(temp)
    return result

def save_file(filename, data):
    """
    Function to save the file in csv file
    """
    source_path = Path(__file__).resolve()
    source_dir = source_path.parent
    filepath = os.path.join(source_dir, filename)
    
    with open(filepath, 'w', newline='') as output_file:
        keys = data[0].keys() if data else []
        writer = csv.DictWriter(output_file, fieldnames=keys)
        writer.writeheader()
        writer.writerows(data)


def run(countries_csv_file, target_countries, sample_ratio, start_date_str, end_date_str):
    initial_data = []
    hold_times = sim_parameters.HOLDING_TIMES
    trans_probs = sim_parameters.TRASITION_PROBS
    age_groups = list(trans_probs.keys())
    state_names = list(hold_times[age_groups[0]].keys())
    
    source_path = Path(__file__).resolve()
    source_dir = source_path.parent
    countries_csv_path = os.path.join(source_dir, countries_csv_file)
    
    try:
        with open(countries_csv_path, 'r') as csv_file:
            csv_data = csv.DictReader(csv_file)
            for row in csv_data:
                country_data = dict(row)
                if country_data['country'] in target_countries:
                    initial_data.append(country_data)
    except FileNotFoundError:
        print(f"Error: {countries_csv_file} not found.")
        return
    
    try:
        start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()
    except ValueError:
        print("Error: Incorrect date format. Please use YYYY-MM-DD.")
        return
    
    date_range_list = [start_date + timedelta(days=i) for i in range((end_date - start_date).days + 1)]

    sample_data, total_population = generate_sample_data(initial_data, sample_ratio, age_groups)

    final_sample_data = []
    for sample_entry in sample_data:
        for date_entry in date_range_list:
            entry_copy = sample_entry.copy()
            entry_copy['date'] = date_entry
            final_sample_data.append(entry_copy)

    possible_states = [[j + i for i in trans_probs[age_groups[0]].keys()] for j in trans_probs[age_groups[0]].keys()]
    
    simulated_output = []
    print("Simulation started....")
    for unique_id in range(total_population):
        test_data = [x for x in final_sample_data if x['unique_id'] == unique_id]
        age_group = test_data[0]['age_group_name']
        try:
            simulation_result = each_person(test_data, trans_probs[age_group], hold_times[age_group], possible_states)
            simulated_output.extend(simulation_result)
        except Exception as e:
            print(f"Error in simulation for unique_id {unique_id}: {e}")
    print("Simulation has completed...")
    
    save_file('a3-covid-simulated-timeseries.csv', simulated_output)
    
    print("Summarising the simulated data...")
    summarised_data = []
    for date_entry in date_range_list:
        for country in target_countries:
            temp_data = [i for i in simulated_output[::-1] if i['country'] == country and i['date'] == date_entry]
            summary_entry = {'date': temp_data[0]['date'], 'country': temp_data[0]['country']}
            for state in state_names:
                state_count = len([j for j in temp_data if j['state'] == state])
                summary_entry[state] = state_count
            summarised_data.append(summary_entry)
    print("Summarising the data is done..")
    
    save_file('a3-covid-summary-timeseries.csv', summarised_data)

    helper.create_plot('a3-covid-summary-timeseries.csv', target_countries)


