import numpy as np

class WeatherSimulation:
    def __init__(self,transition_probabilities,holding_times):
        '''
            constructor to initialise the various parameters
        '''
        self.transition_probabilities = transition_probabilities
        self.holding_times = holding_times
        for state in self.transition_probabilities:
            if sum(self.transition_probabilities[state].values())!=1: 
#condition to check sum of probabilities
                raise RuntimeError("Sum of probabilities should be equal to unity.")
        self.present_state = 'sunny'
        self.count=1
    def get_states(self):
        '''
            Function to return all the states
        '''
        return list(self.transition_probabilities.keys())
    def current_state(self):
        '''
            Function to return the current state
        '''
        return self.present_state
    def next_state(self):
        '''
            Function to predict the next state using numpy random choice method
        '''
        current_probs = list(self.transition_probabilities[self.present_state].values())
        current_states = self.transition_probabilities[self.present_state]
        transition_states = [self.present_state+state for state in current_states]
        if self.current_state_remaining_hours()<=0:
            out = np.random.choice(transition_states, p = current_probs)
            out = out.replace(self.present_state,"",1)
            self.set_state(out)
            self.count=1
        else:
            self.count+=1
    def set_state(self,new_state):
        '''
            Function to set the current state with newly predicted state
        '''
        self.present_state = new_state
    def current_state_remaining_hours(self):
        '''
            Function to calculate the remaining hours from holding time
        '''
        return self.holding_times[self.present_state]-self.count
    def iterable(self):
        '''
            generator to set next state and yield the current state
        '''
        while True:
            self.next_state()
            yield self.current_state()
    def simulate(self,hours):
        '''
            Function to predict the next state for each hour for the given number of hours
            returns the percentage of occurence of each state
        '''
        percentages = {key:0 for key in self.get_states()}
        percentages[self.present_state]+=1
        for h in range(hours):
            self.next_state()
            percentages[self.present_state]+=1
        percentages_list = list(percentages.values())
        final_list = [(i/hours)*100 for i in percentages_list]
        return final_list
